<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Macromedia')); ?></title>

    <!-- Styles -->
    
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/typed/typed.min.js','resources/js/custom.js' ]); ?>

</head>
<body>
    
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('img/macro-bg.png')); ?>" alt="" style="width: 150px; height: auto;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <!-- Left Side Of Navbar -->

                    <nav class="navbar">
                        <div class="container-fluid">
                            <div class="collapse navbar-collapse" id="navbarNav">
                                <ul class="navbar-nav" style="font-family: 'Nunito', sans-serif;">
                                    <li class="nav-item">
                                        <a class="nav-link mx-2" href="<?php echo e(url('/')); ?>">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link mx-2" href="#">Blog</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link dropdown-toggle mx-2" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Services 
                                        &nbsp
                                        <i class="fas fa-chevron-down chevron-icon mr-3"></i>
                                        </a>

                                    <div class="drawer justify-content-center" id="services-drawer">                                        
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <i class="fas fa-film" ></i>Video Editing
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fas fa-palette" style="color:#a794ef;"></i>Graphic Design
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                <i class="fas fa-cogs" style="color:skyblue;"></i>Social Media Management
                                                </a>
                                            </li>                                            
                                            <li>
                                                <a href="#">
                                                    <i class="fas fa-bullhorn" style="color:#58b771;"></i>Social Media Marketing
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fas fa-search-plus" style="color:gray;"></i>Search Engine Optimization
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link mx-2" href="/about">About</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link mx-2" href="/contact-us">Contact Us</a>
                                        
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>


                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        
    </div>



    <?php $__env->startSection('content'); ?>
        <div id="app">
            <button @click="toggleDrawer">Toggle Drawer</button>
            <drawer v-if="showDrawer"></drawer>
        </div>
    <?php $__env->stopSection(); ?>

</body>
</html>
<?php /**PATH C:\Users\chris\Codes\MacroMedia\resources\views/layouts/navbar-with-dropdowns.blade.php ENDPATH**/ ?>